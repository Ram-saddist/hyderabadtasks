package com.codegnan.app;

import java.util.Set;



import com.codegnan.bean.User;
import com.codegnan.dao.DaoImpl;

public class UserApp {

	public static void main(String[] args) {
		DaoImpl ob=new DaoImpl();
		ob.insertUser(new User(0,"shamitha","add@",23));
//Set<User> allUsers = ob.getAllUsers();
//System.out.println(allUsers);
//ob.updateUser(new User(2,"shami","pass",30));
//		ob.deleteUser(5);

	}

}
