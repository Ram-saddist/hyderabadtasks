package com.codegnan.dao;

import java.sql.Connection;


import java.sql.DriverManager;

public class DbConnect {

	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db","root","admin");
			System.out.println("database connected successfully");
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		

	}

}
