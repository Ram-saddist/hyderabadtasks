package com.codegnan.service;

import java.util.Set;


import com.codegnan.bean.User;

public interface UserDao {
	 User getUser(int id);
	    Set<User> getAllUsers();
	    boolean insertUser(User user);
	    boolean updateUser(User user);
	    boolean deleteUser(int id);

}
