import javax.xml.XMLConstants;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.*;
import java.io.*;

public class XSDValidator {

    public static void main(String[] args) throws Exception {
        // Create a SchemaFactory capable of understanding WXS schemas
        SchemaFactory factory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);

        // Load a WXS schema, represented by a Schema instance
        File schemaFile = new File("bookstore.xsd");
        Schema schema = factory.newSchema(schemaFile);

        // Create a Validator instance, which can be used to validate an instance document
        Validator validator = schema.newValidator();

        // Validate the DOM tree
        File xmlFile = new File("bookstore.xml");
        validator.validate(new StreamSource(xmlFile));

        // If the validation is successful, no errors will be printed
        System.out.println("Validation successful!");
    }
}
